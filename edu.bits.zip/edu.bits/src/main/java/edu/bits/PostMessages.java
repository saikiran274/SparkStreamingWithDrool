package edu.bits;

import java.io.IOException;

public class PostMessages {
  public static void main(String[] args) throws InterruptedException, IOException {
	  CustomerDataProducer.postMessageToTopic();
	  //CustomerOfferConsumer.consumeRecords();
}
}
