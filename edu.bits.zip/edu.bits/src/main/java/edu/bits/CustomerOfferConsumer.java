package edu.bits;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import edu.bits.config.KafkaConfig;

public class CustomerOfferConsumer extends KafkaConfig{
	
	public static KafkaConsumer<String,String>  createConsumer(){
		
		Properties consumerProps = new Properties();
        consumerProps.put("bootstrap.servers", KAFKA_BROKERS );

       consumerProps.put("group.id", "KafkaExampleConsumer");
       consumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
       consumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
      
       return new KafkaConsumer<String,String>(consumerProps);
	}
	
	public static void consumeRecords() {
		  Consumer<String, String> consumer =createConsumer();
	         consumer.subscribe(Arrays.asList(topicName));
	         while (true) {
	            ConsumerRecords<String, String> records = consumer.poll(100);
	            for (ConsumerRecord<String, String> record : records)
	            System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
	         }
		
	}

}
