package edu.bits.pojo;

public class CustomerData {
	public String customerId;
	public String inMall;
	public String isArroundMall;
	public CustomerData(String customerId, String inMall, String isArroundMall) {
		super();
		this.customerId = customerId;
		this.inMall = inMall;
		this.isArroundMall = isArroundMall;
	}
	

}
