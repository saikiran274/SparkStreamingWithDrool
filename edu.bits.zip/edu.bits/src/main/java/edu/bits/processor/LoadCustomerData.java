package edu.bits.processor;


import static org.apache.spark.sql.functions.col;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.api.java.UDF3;
import org.apache.spark.sql.api.java.UDF5;
import org.apache.spark.sql.api.java.UDF6;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;
import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;
import static org.apache.spark.sql.functions.from_json;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import edu.bits.config.KafkaConfig;
import edu.bits.pojo.CustomerData;
import edu.bits.pojo.OfferRules;
import edu.bits.spark.SparkSessionObj;

public class LoadCustomerData extends SparkSessionObj {

	public static Dataset<Row> customerData;
	public static Dataset<Row> customersArroundMallData;
	public static PackageBuilder packageBuilder;
	public static WorkingMemory workingMemory;
	public static OfferRules offerRules;
	public static ObjectMapper mapper = new ObjectMapper();
	public static StructType userSchema = new StructType().add("customerId", "string").add("inMall", "string").add("isArroundMall", "string");
	public static Gson gson = new Gson();  
	
/*	public void executeDrools() throws DroolsParserException, IOException {

    	PackageBuilder packageBuilder = new PackageBuilder();

    	String ruleFile = "C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Rules.drl";
    	//InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
    	//Reader reader = new InputStreamReader(resourceAsStream);
    	Reader reader = new InputStreamReader(new FileInputStream(ruleFile));
    	packageBuilder.addPackageFromDrl(reader);
    	org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
    	RuleBase ruleBase = RuleBaseFactory.newRuleBase();
    	ruleBase.addPackage(rulesPackage);

    	WorkingMemory workingMemory = ruleBase.newStatefulSession();

    	OfferRules  offerRules= new OfferRules();
    	offerRules.setAge(41);
    	offerRules.setIncome(6000);
    	offerRules.setIsArroundMall("Y");
    	offerRules.setGender("M");

    	workingMemory.insert(offerRules);
    	workingMemory.fireAllRules();

    	System.out.println(offerRules.getDiscount());
    	}*/
	
	public static void  loadRuleEnginee(String  ruleFile) throws DroolsParserException, IOException {
		packageBuilder = new PackageBuilder();
		Reader reader = new InputStreamReader(new FileInputStream(ruleFile));
    	packageBuilder.addPackageFromDrl(reader);
    	org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
    	RuleBase ruleBase = RuleBaseFactory.newRuleBase();
    	ruleBase.addPackage(rulesPackage);
    	workingMemory = ruleBase.newStatefulSession();
    	
	}

	public static void loadCusometData(String fileName) {

		customerData = sparkSession.read().option("inferschema", "true")
				.option("header", "true").csv(fileName);
		
		customerData.show();
	}
	
	public static void loadCustomerArroundMall(String fileName) {

		customersArroundMallData = sparkSession.read().option("inferschema", "true")
				.option("header", "true").csv(fileName);
		
		customersArroundMallData.show();
	}
	
	public static Dataset joinData() {
		
		Dataset combinedData = customerData.join(customersArroundMallData,"customerId");
		
		return combinedData;
	}
	
	public static void loadUDFIntoSparkSession() {
		
		
		
		
		UDF6 executeRules=new UDF6<String,Integer,Integer,String,String,Integer,String>() {

			public String call(String gender, Integer age, Integer income, String json,String inMall,Integer spendScore)
					throws Exception {
				
				//CustomerData customreData=mapper.readValue(json, CustomerData.class);
				OfferRules offerRules=new OfferRules();
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall("Y");
				offerRules.setIsArroundMall("N");
				offerRules.setSpendScore(spendScore);
				
				workingMemory.insert(offerRules);
		    	workingMemory.fireAllRules();
		    	
		    	
				//return offerRules.getDiscount();
		    	
		    	return mapper.writeValueAsString(offerRules);
			}

		
		};
		
		sparkSession.udf().register("executeRules", executeRules, DataTypes.StringType);
		
		UDF1 executeRule=new UDF1<String,String>() {

			public String call(String input)
					throws Exception {
				
				System.out.println(input);
				
				//workingMemory.insert(offerRules);
		    	//workingMemory.fireAllRules();
		    	
		    	
				return "10";
			}

		
		};
		
		sparkSession.udf().register("executeRule", executeRule, DataTypes.StringType);
		
		
		UDF2 executeRule2=new UDF2<String,String,String>() {

			public String call(String input,String gender)
					throws Exception {
				
				System.out.println(input);
				System.out.println("Gender :"+gender);
				
				//workingMemory.insert(offerRules);
		    	//workingMemory.fireAllRules();
		    	
		    	
				return "10";
			}

		
		};
		
		sparkSession.udf().register("executeRule2", executeRule2, DataTypes.StringType);
		
		UDF3 executeRule3=new UDF3<String,String,Integer,String>() {

			public String call(String input,String gender,Integer age)
					throws Exception {
				
				System.out.println(input);
				System.out.println("Gender :"+gender);
				System.out.println("age :"+age);
				
				//workingMemory.insert(offerRules);
		    	//workingMemory.fireAllRules();
		    	
		    	
				return "10";
			}

		
		};
		
		sparkSession.udf().register("executeRule3", executeRule3, DataTypes.StringType);
		
		
		UDF5 executeRule5=new UDF5<String,String,Integer,Integer,Integer,String>() {

			public String call(String input,String gender,Integer age,Integer income,Integer spendScore)
					throws Exception {
				
				System.out.println(input);
				System.out.println("Gender :"+gender);
				System.out.println("age :"+age);
				CustomerData customreData=gson.fromJson(input, CustomerData.class);
				OfferRules offerRules=new OfferRules();
				offerRules.setCustomerId(customreData.customerId);
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall(customreData.inMall);
				offerRules.setIsArroundMall(customreData.isArroundMall);
				offerRules.setSpendScore(spendScore);
				
				workingMemory.insert(offerRules);
		    	workingMemory.fireAllRules();
		    	System.out.println("outputString :"+mapper.writeValueAsString(offerRules));
		    	
				return mapper.writeValueAsString(offerRules);
			}

		
		};
		
		sparkSession.udf().register("executeRule5", executeRule5, DataTypes.StringType);
	}
	
	public static void executeRuleOnDataSet(Dataset combinedData) {
		combinedData=combinedData.withColumn("Discount", functions.callUDF("executeRules",col("gender"), col("age")
				,col("income")
				,col("inMall")
				,col("isArroundMall")
				,col("spendscore")));
		
		combinedData.show(100,false);
		
	}
	
	public static void loadTheStream() throws StreamingQueryException {
		customerData.show();

		Dataset streamingDf = sparkSession.readStream().format("kafka")
				.option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS).option("subscribe", KafkaConfig.topicName)
				.load().selectExpr("CAST(key AS STRING) as customerId", "CAST(value AS STRING) as json");

		streamingDf.writeStream().format("console").start();
		Dataset combinedJoied = streamingDf.join(customerData, "customerId");

		combinedJoied.writeStream().format("console").start();

		combinedJoied = combinedJoied.withColumn("offer_with_discount", functions.callUDF("executeRule5", col("json"),
				col("gender"), col("age"), col("income"), col("spendScore")));
		
		
		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value")
		.writeStream().format("kafka").option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS)
		.option("topic", KafkaConfig.senderTopicName)
		.option("checkpointLocation","C:\\tmp\\checkPoint\\").start();

		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value")
				.writeStream().format("console").start();
		
		sparkSession.streams().awaitAnyTermination();

		// combinedJoied.writeStream().format("console").start().awaitTermination();

		System.out.println("----------------");

		customerData.show();

	}
	
	public static  void processTheRecords() throws StreamingQueryException {
		sparkSession.readStream().format("kafka")
		.option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS).option("subscribe", KafkaConfig.topicName)
		.load().selectExpr("CAST(key AS STRING) as customerId", "CAST(value AS STRING) as json").writeStream().format("console").start().awaitTermination();
		
		
	}

}
