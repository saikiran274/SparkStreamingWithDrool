package edu.bits;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.fasterxml.jackson.databind.ObjectMapper;

import edu.bits.config.KafkaConfig;
import edu.bits.pojo.CustomerData;

public class CustomerDataProducer extends KafkaConfig{
	
	public static Producer<String, String> createProducer() {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA_BROKERS);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, CLIENT_ID);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		return new KafkaProducer<String, String>(props);
	}
	
	
	public static void postMessageToTopic() throws InterruptedException, IOException {
		String line = "";  
		String splitBy = ",";  
		Producer<String, String> producer = createProducer();
		ObjectMapper objMapper=new ObjectMapper();
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\DataArroundMall.csv"));
		int i=0;
		if(i == 0) {
			br.readLine();
		}
		// sets the delimiter pattern
		while ((line = br.readLine()) != null) {
			System.out.println("Post Message to KafkaTopic");
			System.out.println(line);
			String[] custObj = line.split(splitBy);
			CustomerData customerData = new CustomerData(custObj[0], custObj[1], custObj[2]);

			producer.send(new ProducerRecord<String, String>(topicName, customerData.customerId,
					objMapper.writeValueAsString(customerData)));
			Thread.sleep(5);

		}
		
		/*
		 * 
		 * for (int i = 0; i < 100; i++) { producer.send(new ProducerRecord<String,
		 * String>(topicName, i+"","Sai")); Thread.sleep(5); } producer.close();
		 */

	}
	
	

}
