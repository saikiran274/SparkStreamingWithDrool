package edu.bits;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;

import edu.bits.pojo.OfferRules;
import edu.bits.processor.LoadCustomerData;
import edu.bits.spark.SparkSessionObj;

/**
 * Hello world!
 *
 */
public class App {
	
	public static void main(String[] args) throws DroolsParserException, IOException,InterruptedException, StreamingQueryException {
		//processRules();
		streamingProcess(args);
	}
	
	public static void streamingProcess(String[] args) throws DroolsParserException, IOException, InterruptedException, StreamingQueryException {
		System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
		System.setProperty("hadoop.tmp.dir", "C:\\tmp\\tmp");
		SparkSessionObj.loadSparkSesison();
		LoadCustomerData.loadUDFIntoSparkSession();
		LoadCustomerData.loadRuleEnginee("C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Rules.drl");
		LoadCustomerData
		.loadCusometData("C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Mall_Customers.csv");
		//CustomerDataProducer.postMessageToTopic();
		LoadCustomerData.loadTheStream();
		//LoadCustomerData.processTheRecords();

	}
	public static void processRules()  throws DroolsParserException, IOException {
		App app = new App();
		app.executeDrools();
				
		System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
		SparkSessionObj.loadSparkSesison();
		LoadCustomerData.loadRuleEnginee("C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Rules.drl");
		LoadCustomerData
				.loadCusometData("C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Mall_Customers.csv");
		LoadCustomerData.loadCustomerArroundMall(
				"C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\DataArroundMall.csv");
		Dataset combinedData = LoadCustomerData.joinData();
		
		LoadCustomerData.loadUDFIntoSparkSession();
		LoadCustomerData.executeRuleOnDataSet(combinedData);
	}

	public void executeDrools() throws DroolsParserException, IOException {

    	PackageBuilder packageBuilder = new PackageBuilder();

    	String ruleFile = "C:\\Users\\Chandu\\workspace\\edu.bits\\src\\main\\resources\\Rules.drl";
    	//InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
    	//Reader reader = new InputStreamReader(resourceAsStream);
    	Reader reader = new InputStreamReader(new FileInputStream(ruleFile));
    	packageBuilder.addPackageFromDrl(reader);
    	org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
    	RuleBase ruleBase = RuleBaseFactory.newRuleBase();
    	ruleBase.addPackage(rulesPackage);

    	WorkingMemory workingMemory = ruleBase.newStatefulSession();

    	OfferRules  offerRules= new OfferRules();
    	offerRules.setAge(41);
    	offerRules.setIncome(6000);
    	offerRules.setIsArroundMall("Y");
    	offerRules.setGender("F");

    	workingMemory.insert(offerRules);
    	workingMemory.fireAllRules();

    	System.out.println(offerRules.getDiscount());
    	}
}
