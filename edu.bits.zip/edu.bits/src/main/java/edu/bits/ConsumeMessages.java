package edu.bits;

public class ConsumeMessages {
	
	public static void main(String[] args) {
		CustomerOfferConsumer.consumeRecords();
	}

}
