package edu.bits;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.bits.config.KafkaConfig;
import edu.bits.pojo.CustomerData;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class CustomerTextDataProducer extends KafkaConfig {

	public static Producer<String, String> createProducer() {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA_BROKERS);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, CLIENT_ID);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		return new KafkaProducer<String, String>(props);
	}

	public static void main(String[] args) throws InterruptedException {
		Producer<String, String> producer = createProducer();
		ObjectMapper objMapper = new ObjectMapper();
		String customerId="3";
		String chatInfo="Lucky";
		producer.send(new ProducerRecord<String, String>(chatDataTopic,customerId , chatInfo));
		Thread.sleep(1000);
	}



}
