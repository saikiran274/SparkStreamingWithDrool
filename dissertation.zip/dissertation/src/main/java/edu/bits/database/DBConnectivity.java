package edu.bits.database;

import java.sql.*;

public class DBConnectivity {
    public static void main(String args[]){
        try{

            String query = " insert into test (id) values (?)";
            Connection conn = DBConnection.getConnection();
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setString (1, "Barney");
            preparedStmt.execute();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
