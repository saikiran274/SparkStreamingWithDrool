package edu.bits.database;

import java.sql.*;

public class DBConnection {

    public static void main(String[] args) {
        getConnection();
    }

    public static Connection conn= null;

    public static Connection getConnection(){
      if(conn == null) {
          try {
              Class.forName("com.mysql.cj.jdbc.Driver");
              conn = DriverManager.getConnection(
                      "jdbc:mysql://localhost:3306/dissertation", "root", "13121988Ts!");

              System.out.println(conn);
          } catch (Exception e) {
              System.out.println(e);
          }
      }

        return conn;
    }
}
