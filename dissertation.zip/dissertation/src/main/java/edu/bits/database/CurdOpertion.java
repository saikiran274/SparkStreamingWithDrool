package edu.bits.database;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import edu.bits.pojo.OfferRules;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CurdOpertion {

    static String inputQuery="insert into cutomer_discount" +
            " (customerId,gender,age,income,spendScore,inMall,isArroundMall,distance,discount) " +
            "values (?,?,?,?,?,?,?,?,?)";
    public static ObjectMapper mapper = new ObjectMapper();
    public static Gson gson = new Gson();
    public static void insertOutPut(String json)  {
        try {
            OfferRules offerRule=mapper.readValue(json,OfferRules.class);
            Connection conn = DBConnection.getConnection();
            PreparedStatement preparedStmt = conn.prepareStatement(inputQuery);
            preparedStmt.setString (1, offerRule.customerId);
            preparedStmt.setString (2, offerRule.gender);
            preparedStmt.setString (3, String.valueOf(offerRule.age));
            preparedStmt.setString (4, String.valueOf(offerRule.income));
            preparedStmt.setString (5, String.valueOf(offerRule.spendScore));
            preparedStmt.setString (6, offerRule.inMall);
            preparedStmt.setString (7, offerRule.isArroundMall);
            preparedStmt.setString (8, String.valueOf(offerRule.distance));
            preparedStmt.setString (9, offerRule.discount);
            preparedStmt.execute();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
