package edu.bits.spark;

import org.apache.spark.sql.SparkSession;

public class SparkSessionObj {

	public static SparkSession sparkSession;

	public static void loadSparkSesison() {
		sparkSession = SparkSession.builder().master("local").getOrCreate();
		sparkSession.sparkContext().setLogLevel("ERROR");
	}

}
