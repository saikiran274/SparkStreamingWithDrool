package edu.bits.processor;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Collections;
import java.util.List;

import edu.bits.algo.DiscountPrediction;
import org.apache.spark.sql.*;
import org.apache.spark.sql.api.java.*;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.IntegerType;
import org.apache.spark.sql.types.StructType;
import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import edu.bits.config.KafkaConfig;
import edu.bits.pojo.CustomerData;
import edu.bits.pojo.OfferRules;
import edu.bits.spark.SparkSessionObj;

import static org.apache.spark.sql.functions.*;

public class LoadCustomerData extends SparkSessionObj {

	public static Dataset<Row> customerData;
	public static Dataset<Row> customersArroundMallData;
	public static PackageBuilder packageBuilder;
	public static WorkingMemory workingMemory;
	public static OfferRules offerRules;
	public static ObjectMapper mapper = new ObjectMapper();
	public static StructType userSchema = new StructType().add("customerId", "string").add("inMall", "string")
			.add("isArroundMall", "string");
	public static Gson gson = new Gson();

	public static void loadRuleEnginee(String ruleFile) throws DroolsParserException, IOException {

		System.out.println(" Loading  DROOL  Rule Engine ");

		packageBuilder = new PackageBuilder();
		Reader reader = new InputStreamReader(new FileInputStream(ruleFile));
		packageBuilder.addPackageFromDrl(reader);
		org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
		RuleBase ruleBase = RuleBaseFactory.newRuleBase();
		ruleBase.addPackage(rulesPackage);
		workingMemory = ruleBase.newStatefulSession();

	}

	public static void loadCusometData(String fileName) {

		System.out.println(" Loading  Customer Data  Present with Organization ");

		customerData = sparkSession.read().option("inferschema", "true").option("header", "true").csv(fileName);

		customerData.show();
	}

	public static void loadCustomerArroundMall(String fileName) {

		customersArroundMallData = sparkSession.read().option("inferschema", "true").option("header", "true")
				.csv(fileName);

		customersArroundMallData.show();
	}

	public static void loadCustomerDistance(String fileName) {

		System.out.println(" Loading the data of the customer from network who are near to mall");

		Dataset<Row> customerDataFromMall = sparkSession.read().option("inferschema", "true").option("header", "true")
				.csv(fileName);



		customerDataFromMall = customerDataFromMall
				.withColumn("inMall", functions.callUDF("inMalRule", col("distance")))
				.withColumn("isArroundMall", functions.callUDF("isArroundMall1", col("distance")));

		customerDataFromMall.show();


		customersArroundMallData = customerDataFromMall.drop(col("distance"));

		//customersArroundMallData.show();
	}

	public static Dataset joinData() {

		Dataset combinedData = customerData.join(customersArroundMallData, "customerId");

		return combinedData;
	}

	public static void loadUDFIntoSparkSession() {

		System.out.println("Loading all the required  UDF ");

		UDF6 executeRules = new UDF6<String, Integer, Integer, String, String, Integer, String>() {

			public String call(String gender, Integer age, Integer income, String json, String inMall,
					Integer spendScore) throws Exception {

				// CustomerData customreData=mapper.readValue(json, CustomerData.class);
				OfferRules offerRules = new OfferRules();
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall("Y");
				offerRules.setIsArroundMall("N");
				offerRules.setSpendScore(spendScore);

				workingMemory.insert(offerRules);
				workingMemory.fireAllRules();

				// return offerRules.getDiscount();

				return mapper.writeValueAsString(offerRules);
			}

		};

		sparkSession.udf().register("executeRules", executeRules, DataTypes.StringType);

		UDF2 getFinalDiscount = new UDF2<String, Double,String>() {

			public String call(String input,Double prediction) throws Exception {

				OfferRules offerRules=gson.fromJson(input, OfferRules.class);

			int discount= (int) Math.round(prediction);

			 if(offerRules.discount == null){
				 offerRules.discount="0";
			 }

				int  discountValue =  discount > Integer.parseInt(offerRules.discount)
						? discount: Integer.parseInt(offerRules.discount);
				System.out.println("--------Discount calculation Start-------");
			    System.out.println(" Input Data "+input);
				System.out.println(" Discount from Rule Engine :"+offerRules.discount);
				System.out.println("Discount from Algo prediction:"+prediction);
				System.out.println("Final Discount :"+discountValue);
				System.out.println("--------Discount calculation  End-------");
				return String.valueOf(discountValue);
			}

		};

		sparkSession.udf().register("getFinalDiscount", getFinalDiscount, DataTypes.StringType);

		UDF2 executeRule2 = new UDF2<String, String, String>() {

			public String call(String input, String gender) throws Exception {

				System.out.println(input);
				System.out.println("Gender :" + gender);

				// workingMemory.insert(offerRules);
				// workingMemory.fireAllRules();

				return "10";
			}

		};

		sparkSession.udf().register("executeRule2", executeRule2, DataTypes.StringType);

		UDF3 executeRule3 = new UDF3<String, String, Integer, String>() {

			public String call(String input, String gender, Integer age) throws Exception {

				System.out.println(input);
				System.out.println("Gender :" + gender);
				System.out.println("age :" + age);

				// workingMemory.insert(offerRules);
				// workingMemory.fireAllRules();

				return "10";
			}

		};

		sparkSession.udf().register("executeRule3", executeRule3, DataTypes.StringType);

		UDF5 executeRule5 = new UDF5<String, String, Integer, Integer, Integer, String>() {

			public String call(String input, String gender, Integer age, Integer income, Integer spendScore)
					throws Exception {

				System.out.println(input);
				System.out.println("Gender :" + gender);
				System.out.println("age :" + age);
				CustomerData customreData = gson.fromJson(input, CustomerData.class);
				OfferRules offerRules = new OfferRules();
				offerRules.setCustomerId(customreData.customerId);
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall(customreData.inMall);
				offerRules.setIsArroundMall(customreData.isArroundMall);
				offerRules.setSpendScore(spendScore);

				workingMemory.insert(offerRules);
				workingMemory.fireAllRules();
				System.out.println("outputString :" + mapper.writeValueAsString(offerRules));

				return mapper.writeValueAsString(offerRules);
			}

		};

		sparkSession.udf().register("executeRule5", executeRule5, DataTypes.StringType);

		UDF1 inMalRule = new UDF1<Integer, String>() {

			public String call(Integer distance) throws Exception {
				String inMall = "N";
				if (distance <= 100) {
					inMall = "Y";
				}

				return inMall;
			}

		};

		sparkSession.udf().register("inMalRule", inMalRule, DataTypes.StringType);

		UDF1 isArroundMall = new UDF1<String, String>() {

			public String call(String distance) throws Exception {
				String isArroundMall = "N";
				if (Integer.parseInt(distance) > 100 && Integer.parseInt(distance) <= 600) {
				//if(distance > 100 && distance <= 600){
				isArroundMall = "Y";
				}

				return isArroundMall;
			}

		};

		sparkSession.udf().register("isArroundMall", isArroundMall, DataTypes.StringType);


		UDF1 inMalRule1 = new UDF1<String, String>() {

			public String call(String distance) throws Exception {
				String inMall = "N";
				if (Integer.parseInt(distance) <= 100) {
					inMall = "Y";
				}

				return inMall;
			}

		};

		sparkSession.udf().register("inMalRule1", inMalRule1, DataTypes.StringType);

		UDF1 isArroundMall1 = new UDF1<Integer, String>() {

			public String call(Integer distance) throws Exception {
				String isArroundMall = "N";
				if (distance > 100 && distance <= 600) {

					isArroundMall = "Y";
				}

				return isArroundMall;
			}

		};

		sparkSession.udf().register("isArroundMall1", isArroundMall1, DataTypes.StringType);

		UDF7 executeRuleForDistance = new UDF7<String, String, String, String, Integer, Integer, Integer, String>() {

			public String call(String customerId, String inMall, String isArroundMall, String gender, Integer age,
					Integer income, Integer spendScore) throws Exception {

				//System.out.println("Gender :" + gender);
				//System.out.println("age :" + age);
				OfferRules offerRules = new OfferRules();
				offerRules.setCustomerId(customerId);
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall(inMall);
				offerRules.setIsArroundMall(isArroundMall);
				offerRules.setSpendScore(spendScore);

				workingMemory.insert(offerRules);
				workingMemory.fireAllRules();
				System.out.println("outputString :" + mapper.writeValueAsString(offerRules));




				return mapper.writeValueAsString(offerRules);
			}

		};
		sparkSession.udf().register("executeRuleForDistance", executeRuleForDistance, DataTypes.StringType);

		UDF8 executeRuleForDistances =new UDF8<String, String, String, String, Integer, Integer, Integer,String, String>() {

			public String call(String customerId, String inMall, String isArroundMall, String gender, Integer age,
							   Integer income, Integer spendScore,String distance) throws Exception {

				//System.out.println("Gender :" + gender);
				//System.out.println("age :" + age);
				OfferRules offerRules = new OfferRules();
				offerRules.setCustomerId(customerId);
				offerRules.setGender(gender);
				offerRules.setAge(age);
				offerRules.setIncome(income);
				offerRules.setInMall(inMall);
				offerRules.setIsArroundMall(isArroundMall);
				offerRules.setSpendScore(spendScore);
				//offerRules.setDistance(distance);
				offerRules.setDistance(Integer.parseInt(distance));

				workingMemory.insert(offerRules);
				workingMemory.fireAllRules();
				System.out.println("outputString :" + mapper.writeValueAsString(offerRules));




				return mapper.writeValueAsString(offerRules);
			}

		};
		sparkSession.udf().register("executeRuleForDistances", executeRuleForDistances, DataTypes.StringType);

	}

	public static void executeRuleOnDataSet(Dataset combinedData) {
		combinedData = combinedData.withColumn("Discount", functions.callUDF("executeRules", col("gender"), col("age"),
				col("income"), col("inMall"), col("isArroundMall"), col("spendscore")));

		combinedData.show(100, false);

	}

	public static void loadTheStream() throws StreamingQueryException {
		customerData.show();

		Dataset streamingDf = sparkSession.readStream().format("kafka")
				.option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS).option("subscribe", KafkaConfig.topicName)
				.load().selectExpr("CAST(key AS STRING) as customerId", "CAST(value AS STRING) as json");

		//streamingDf.writeStream().format("console").start();
		Dataset combinedJoied = streamingDf.join(customerData, "customerId");

		combinedJoied.writeStream().format("console").start();

		combinedJoied = combinedJoied.withColumn("offer_with_discount",
				functions.callUDF("executeRule5", col("json"),
				col("gender"), col("age"), col("income"), col("spendScore")));




		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value")
				.writeStream().format("kafka").option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS)
				.option("topic", KafkaConfig.senderTopicName).option("checkpointLocation", "C:\\tmp\\checkPoint\\")
				.start();



		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value")
				.writeStream().format("console").start();

		sparkSession.streams().awaitAnyTermination();

		// combinedJoied.writeStream().format("console").start().awaitTermination();

		System.out.println("----------------");

		customerData.show();

	}

	public static void processTheRecords() throws StreamingQueryException, InterruptedException {

		System.out.println("----Start processing the Streaming records------");

		Dataset streamingDf = sparkSession.readStream().format("kafka")
				.option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS)
				.option("subscribe", KafkaConfig.topicName)
				.option("failOnDataLoss", "false")
				.load().selectExpr("CAST(key AS STRING) as customerId", "CAST(value AS STRING) as distance","CAST(offset AS STRING) as offset");

		System.out.println("processTheRecords : Input Data Read");
		streamingDf.writeStream().format("console").start();
		customerData.show();

		streamingDf = streamingDf.withColumn("inMall",
				functions.callUDF("inMalRule1", col("distance")))
				.withColumn("isArroundMall",
						functions.callUDF("isArroundMall", col("distance")));


		streamingDf.writeStream().format("console").start();

		Dataset combinedJoied = streamingDf.join(customerData, "customerId");

		/*combinedJoied = combinedJoied.withColumn("offer_with_discount",
				functions.callUDF("executeRuleForDistance", col("customerId"),
						col("inMall"), col("isArroundMall"),
						col("gender"), col("age"), col("income"), col("spendScore")));
*/

		combinedJoied = combinedJoied.withColumn("offer_with_discount",
				functions.callUDF("executeRuleForDistances", col("customerId"),
						col("inMall"), col("isArroundMall"),
						col("gender"), col("age"), col("income"),
						col("spendScore"),col("distance")));

		Dataset records = readDataFromTopic();

		Dataset combinedJoiedTemp =combinedJoied.join(records,"customerId");

		combinedJoiedTemp=combinedJoiedTemp.withColumn("final_discount",
				functions.callUDF("getFinalDiscount",col("offer_with_discount"),
						col("prediction")));

		System.out.println("----*********----");
		combinedJoiedTemp.writeStream().format("console").start();
		System.out.println("----***End****----");

		System.out.println("Records Processed to kafka topic");

		//Thread.sleep(5000);
		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value")
				.writeStream().format("kafka").option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS)
				.option("topic", KafkaConfig.senderTopicName).option("checkpointLocation", "/Users/saikiran/spark-stream-tmp/")
				.start();

		combinedJoied.selectExpr("CAST(customerId AS STRING) as key", "CAST(offer_with_discount AS STRING) as value").writeStream().format("console").start();



		streamingDf.writeStream().format("console").start();
		sparkSession.streams().awaitAnyTermination();
	}

	public static Dataset readDataFromTopic(){

		Dataset readDf = sparkSession.read().format("kafka")
				.option("kafka.bootstrap.servers", KafkaConfig.KAFKA_BROKERS).option("subscribe", KafkaConfig.topicName)
				.load().selectExpr("CAST(key AS STRING) as customerId", "CAST(value AS STRING) as distance");

		readDf = readDf.withColumn("inMall", functions.callUDF("inMalRule1", col("distance")))
				.withColumn("isArroundMall", functions.callUDF("isArroundMall", col("distance")))
				.withColumn("discount",lit("0"));

		readDf = readDf.distinct();

		Dataset<Row> combinedJoied = readDf.join(customerData, "customerId");

		combinedJoied= combinedJoied.drop("distance");
		combinedJoied = combinedJoied.withColumn("distance",lit(0));

		combinedJoied.show();

		Encoder<OfferRules> offerRulesEncoder = Encoders.bean(OfferRules.class);
		Dataset<OfferRules> combinedJoie = combinedJoied.as(offerRulesEncoder);

		System.out.println("Executing the prediction logic");

		Dataset<Row>  output=DiscountPrediction.getDiscountValues(combinedJoied);

		output.show();

		return output;
	}

}
