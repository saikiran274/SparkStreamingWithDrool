package edu.bits;
import java.util.Arrays;

import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.feature.VectorSizeHint;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import static org.apache.spark.sql.types.DataTypes.*;


public class MultiRegression {

    public static void main(String[] args) {
        executeLinearRegression ();
    }

    public static void executeLinearRegression(){
        SparkSession spark = SparkSession.builder().master("local").getOrCreate();
        Dataset<Row>  df=spark.read().format("csv")
                .option("header", "true").
                option("inferschema","true").load("/Users/saikiran/Downloads/BostonHousing.csv");
       df.show(false);

        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(new String[]{"crim", "zn", "indus", "chas", "nox", "rm", "age", "dis", "rad", "tax", "ptratio", "b", "lstat"})
                .setOutputCol("features");


        Dataset<Row>  df_transfrom=assembler.transform(df);
        df_transfrom.show(false);

        Dataset<Row>[] splits = df_transfrom.randomSplit(new double[]{0.7, 0.3});
        Dataset<Row> trainingData = splits[0];
        Dataset<Row> testData = splits[1];

        LinearRegression lr = new LinearRegression()
                .setLabelCol("medv")
                .setFeaturesCol("features");

        LinearRegressionModel regressionModel = lr.fit(trainingData);


        Dataset<Row> output=regressionModel.transform(testData);

        output.select("prediction").show();













    }


    public static void execute (){
        SparkSession spark = SparkSession.builder().master("local").getOrCreate();
        StructType schema = createStructType(new StructField[]{
                createStructField("id", IntegerType, false),
                createStructField("hour", IntegerType, false),
                createStructField("mobile", DoubleType, false),
                createStructField("userFeatures", new VectorUDT(), false),
                createStructField("clicked", DoubleType, false)
        });
        Row row0 = RowFactory.create(0, 18, 1.0, Vectors.dense(0.0, 10.0, 0.5), 1.0);
        Row row1 = RowFactory.create(0, 18, 1.0, Vectors.dense(0.0, 10.0), 0.0);
        Dataset<Row> dataset = spark.createDataFrame(Arrays.asList(row0, row1), schema);

        VectorSizeHint sizeHint = new VectorSizeHint()
                .setInputCol("userFeatures")
                .setHandleInvalid("skip")
                .setSize(3);

        Dataset<Row> datasetWithSize = sizeHint.transform(dataset);
        System.out.println("Rows where 'userFeatures' is not the right size are filtered out");
        datasetWithSize.show(false);

        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(new String[]{"hour", "mobile", "userFeatures"})
                .setOutputCol("features");

// This dataframe can be used by downstream transformers as before
        Dataset<Row> output = assembler.transform(datasetWithSize);
        System.out.println("Assembled columns 'hour', 'mobile', 'userFeatures' to vector column " +
                "'features'");
        output.select("features", "clicked").show(false);
    }
}
