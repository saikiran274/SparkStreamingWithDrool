package edu.bits.pojo;

public class CustomRules {
}
