package edu.bits.algo;

import edu.bits.pojo.OfferRules;
import edu.bits.spark.SparkSessionObj;
import org.apache.avro.generic.GenericData;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.DecisionTreeClassifier;
import org.apache.spark.ml.classification.DecisionTreeClassificationModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.evaluation.RegressionEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.DecisionTreeRegressionModel;
import org.apache.spark.ml.regression.DecisionTreeRegressor;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.sql.*;
import org.apache.spark.sql.Dataset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DiscountPrediction extends SparkSessionObj {
    static LinearRegression lr=null;
    static LinearRegressionModel regressionModel=null;
    static VectorAssembler assembler=null;
    public static void main(String[] args) {
        SparkSessionObj.loadSparkSesison();
        DiscountPrediction dp=new DiscountPrediction();
        DiscountPrediction.prepareLDecisionTreeClassificationModel();
        //DiscountPrediction.prepareLinerRegressionModel();
        //dp.execute();
        /*
        customerid,age,income,inMall,isArroundMall,distance,spendScore,gender,discount
        20,46,3427,N,N,793,613,N,3
        96,45,19764,Y,N,812,406,N,8
         */
        //DiscountPrediction.excuteAlgo("20","F",46,19764,406,"Y","N",812,"");
    }


    public static DecisionTreeRegressionModel prepareLDecisionTreeClassificationModel(){
        Dataset<Row> df=sparkSession.read().format("csv")
                .option("header", "true").
                        option("inferschema","true").load("/Users/saikiran/Documents/dissertation/src/main/resources/MLDataset.csv");
        df.show(false);

        Pipeline pipeline= oneHotEnCodePreparation();

        Dataset<Row> df_r = pipeline.fit(df).transform(df);
        df_r.show();

        VectorAssembler vectorAssembler = new VectorAssembler()
                .setInputCols(new String[]{"age","income","gender_index","inMall_index","isArroundMall_index","distance","spendScore"})
                .setOutputCol("features");

        Dataset<Row>  df_transfrom=vectorAssembler.transform(df_r);

        Dataset<Row>[] splits = df_transfrom.randomSplit(new double[]{0.7, 0.3});
        Dataset<Row> trainingData = splits[0];
        Dataset<Row> testData = splits[1];

        DecisionTreeRegressor dtc = new DecisionTreeRegressor()
                .setLabelCol("discount")
                .setFeaturesCol("features");
        DecisionTreeRegressionModel model = dtc.fit(df_transfrom);


        Dataset predictions = model.transform(testData);

        predictions.show(5);

        RegressionEvaluator evaluator = new RegressionEvaluator()
                .setLabelCol("discount")
                .setPredictionCol("prediction")
                .setMetricName("rmse");
        double rmse = evaluator.evaluate(predictions);
        System.out.println("Root Mean Squared Error (RMSE) on test data = " + rmse);

        DecisionTreeRegressionModel treeModel =
                (DecisionTreeRegressionModel)(model);
        System.out.println("Learned regression tree model:\n" + treeModel.toDebugString());



        return  model;
    }
    public static LinearRegressionModel prepareLinerRegressionModel(){

        System.out.println("Prepare the ML Model ");

        Dataset<Row> df=sparkSession.read().format("csv")
                .option("header", "true").
                        option("inferschema","true").load("/Users/saikiran/Documents/dissertation/src/main/resources/MLDataset.csv");
        df.show(false);

        Pipeline pipeline= oneHotEnCodePreparation();

        Dataset<Row> df_r = pipeline.fit(df).transform(df);
        df_r.show();

        VectorAssembler vectorAssembler = getAssembler();

        Dataset<Row>  df_transfrom=vectorAssembler.transform(df_r);

        Dataset<Row>[] splits = df_transfrom.randomSplit(new double[]{0.7, 0.3});
        Dataset<Row> trainingData = splits[0];
        Dataset<Row> testData = splits[1];

        lr = new LinearRegression()
                .setLabelCol("discount")
                .setFeaturesCol("features");
        regressionModel = lr.fit(df_transfrom);
        System.out.println("Model Summary ");
        System.out.println(regressionModel.summary());



        return  regressionModel;
    }

    public static LinearRegressionModel getRegressionModel(){
        return regressionModel;
    }

    public  static Pipeline oneHotEnCodePreparation(){
        StringIndexer genderIndex = new StringIndexer()
                .setInputCol("gender")
                .setOutputCol("gender_index");

        StringIndexer inMallIndex = new StringIndexer()
                .setInputCol("inMall")
                .setOutputCol("inMall_index");

        StringIndexer isArroundMallIndex = new StringIndexer()
                .setInputCol("isArroundMall")
                .setOutputCol("isArroundMall_index");

        Pipeline pipeline = new Pipeline()
                .setStages(new PipelineStage[] {genderIndex, inMallIndex, isArroundMallIndex});
        return pipeline;
    }
    public static LinearRegression generateTheAlog(){
        LinearRegression  lr = new LinearRegression()
                .setLabelCol("discount")
                .setFeaturesCol("features");
        return lr;
    }

    public static DecisionTreeClassifier getDecisionTree(){
        DecisionTreeClassifier dt = new DecisionTreeClassifier()
                .setLabelCol("discount")
                .setFeaturesCol("features");

        return dt;
    }

    public static VectorAssembler getAssembler(){
        assembler = new VectorAssembler()
                .setInputCols(new String[]{"distance","age","inMall_index","isArroundMall_index","gender_index","spendScore"})
                .setOutputCol("features");

        return assembler;
    }

    public  static void execute(){
        SparkSession spark = SparkSession.builder().master("local").getOrCreate();
        Dataset<Row> df=spark.read().format("csv")
                .option("header", "true").
                        option("inferschema","true").load("/Users/saikiran/Documents/dissertation/src/main/resources/MLDataset.csv");
        df.show(false);

        Pipeline pipeline= oneHotEnCodePreparation();

        Dataset<Row> df_r = pipeline.fit(df).transform(df);
        df_r.show();

        assembler = new VectorAssembler()
                .setInputCols(new String[]{"distance","age","inMall_index","isArroundMall_index","gender_index","spendScore"})
                .setOutputCol("features");

        Dataset<Row>  df_transfrom=assembler.transform(df_r);

        Dataset<Row>[] splits = df_transfrom.randomSplit(new double[]{0.7, 0.3});
        Dataset<Row> trainingData = splits[0];
        Dataset<Row> testData = splits[1];




         lr = new LinearRegression()
                .setLabelCol("discount")
                .setFeaturesCol("features");
         regressionModel = lr.fit(df_transfrom);


        Dataset<Row> output=regressionModel.transform(df_transfrom);

        output.select("discount","prediction").show();

        Dataset<Row> dfNew=spark.read().format("csv")
                .option("header", "true").
                        option("inferschema","true").load("/Users/saikiran/Documents/dissertation/src/main/resources/MLDataSets1.csv");
        dfNew.show(false);

        Dataset<Row> df_r_n = pipeline.fit(dfNew).transform(dfNew);

        Dataset<Row>  df_transfrom_new=assembler.transform(df_r_n);

        Dataset<Row> output_new=regressionModel.transform(df_transfrom_new);

        output_new.select("discount","prediction").show();

    }

    public static int excuteAlgo( String customerId,
             String gender,
             int age,
             int income,
             int spendScore,
             String inMall,
             String isArroundMall,
             int distance,
             String discount
    ){

        OfferRules offerRules = new OfferRules();
        offerRules.setCustomerId(customerId);
        offerRules.setGender(gender);
        offerRules.setAge(age);
        offerRules.setIncome(income);
        offerRules.setSpendScore(spendScore);
        offerRules.setInMall(inMall);
        offerRules.setIsArroundMall(isArroundMall);
        offerRules.setDistance(distance);
        offerRules.setDiscount(discount);

        System.out.println("----getDataSet----");
        System.out.println(offerRules);

        Dataset<OfferRules> offerDataSet=getDataSet(offerRules);


        int discountValue =getDiscountValue(offerDataSet);

        System.out.println(discountValue);

        return discountValue;
    }

    public static Dataset<OfferRules> getDataSet(OfferRules offerRules ){
        Encoder<OfferRules> offerRulesEncoder = Encoders.bean(OfferRules.class);
        System.out.println("---------------");
        SparkSession spark = SparkSession.builder().master("local").getOrCreate();
        Dataset<OfferRules> offerDataSet = spark.createDataset(
                Collections.singletonList(offerRules),
                offerRulesEncoder
        );

        offerDataSet.show();

        return offerDataSet;
    }

    public static int getDiscountValue (Dataset<OfferRules> offerDataSet){
        Pipeline pipeline= oneHotEnCodePreparation();
        Dataset<Row> df_r = pipeline.fit(offerDataSet).transform(offerDataSet);
        VectorAssembler vectorAssembler = getAssembler();
        Dataset<Row>  df_transfrom=assembler.transform(df_r);
        LinearRegressionModel regressionModel=getRegressionModel();
        Dataset<Row> output=regressionModel.transform(df_transfrom);
        int discountValue= (int) Math.round((Double) output.select("prediction").first().get(0));
        return discountValue;
    }

    public static Dataset getDiscountValues (Dataset<Row> offerDataSet){
        Pipeline pipeline= oneHotEnCodePreparation();
        Dataset<Row> df_r = pipeline.fit(offerDataSet).transform(offerDataSet);
        VectorAssembler vectorAssembler = getAssembler();
        Dataset<Row>  df_transfrom=assembler.transform(df_r);
        LinearRegressionModel regressionModel=getRegressionModel();
        Dataset<Row> output=regressionModel.transform(df_transfrom);

        return output;
    }




}
