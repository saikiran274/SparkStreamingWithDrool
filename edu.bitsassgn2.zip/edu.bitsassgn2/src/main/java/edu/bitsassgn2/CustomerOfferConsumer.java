package edu.bitsassgn2;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import edu.bitsassgn2.config.KafkaConfig;

public class CustomerOfferConsumer extends KafkaConfig {

	public static KafkaConsumer<String, String> createConsumer() {

		Properties consumerProps = new Properties();
		consumerProps.put("bootstrap.servers", KAFKA_BROKERS);
		consumerProps.put("auto.offset.reset", "earliest");
		consumerProps.put("group.id", "KafkaExampleConsumer");
		consumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

		return new KafkaConsumer<String, String>(consumerProps);
	}

	public static void consumeRecords() {
		Consumer<String, String> consumer = createConsumer();
		consumer.subscribe(Arrays.asList(senderTopicName));
		System.out.println("consumeRecords  ");
		while (true) {

			ConsumerRecords<String, String> records = consumer.poll(100);
			for (ConsumerRecord<String, String> record : records)
				System.out.printf("Received MSG from :- topicName=%s, offset = %d, key = %s, value = %s%n",
						senderTopicName, record.offset(), record.key(), record.value());
		}

	}

}
