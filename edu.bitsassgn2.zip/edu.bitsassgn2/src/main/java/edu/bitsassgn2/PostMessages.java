package edu.bitsassgn2;

import java.io.IOException;

public class PostMessages {
  public static void main(String[] args) throws InterruptedException, IOException {
	  //CustomerDataProducer.postMessageToTopic();
	 // CustomerOfferConsumer.consumeRecords();
	  CustomerDataProducer.postDistanceMessageToTopic(0);
}
}
