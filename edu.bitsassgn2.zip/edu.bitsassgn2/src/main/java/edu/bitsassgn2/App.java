package edu.bitsassgn2;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;

import edu.bitsassgn2.config.KafkaConfig;
import edu.bitsassgn2.pojo.OfferRules;
import edu.bitsassgn2.processor.LoadCustomerData;
import edu.bitsassgn2.spark.SparkSessionObj;

/**
 * Hello world!
 *
 */
public class App extends Thread {

	public void run() {

		if (this.getName().equals("Start Streaming")) {
			System.out.println("Starting Streaming process");
			System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
			System.setProperty("hadoop.tmp.dir", "C:\\tmp\\tmp");
			SparkSessionObj.loadSparkSesison();
			LoadCustomerData.loadUDFIntoSparkSession();
			try {
				LoadCustomerData.loadRuleEnginee(".\\src\\main\\resources\\Rules.drl");
				LoadCustomerData.loadCusometData(".\\src\\main\\resources\\Mall_Customers.csv");
				// LoadCustomerData.loadCustomerDistance(".\\src\\main\\resources\\CustomerDetailsNearMall.csv");
				LoadCustomerData.processTheRecords();
			} catch (DroolsParserException | IOException | StreamingQueryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (this.getName().equals("Producer Production")) {
			System.out.println("Starting 1stProducer after 15 sec of applicaion start Productioning ");
			try {
				CustomerDataProducer.postDistanceMessageToTopic(1500);
			} catch (InterruptedException | IOException e) {

				e.printStackTrace();
			}
		} else if (this.getName().equals("Producer 2nd Production")) {
			System.out.println("Starting 2stProducer after 40 sec of applicaion start  Productioning ");
			try {
				CustomerDataProducer.postDistanceMessageToTopic(40000);
			} catch (InterruptedException | IOException e) {

				e.printStackTrace();
			}
		} else if (this.getName().equals("Consumer Start Consuming")) {
			System.out.println("Starting Consumer process ");
			CustomerOfferConsumer.consumeRecords();
		} else {
			System.out.println("Dummy Thread ");
		}

	}

	public static void main(String[] args)
			throws DroolsParserException, IOException, InterruptedException, StreamingQueryException {
		// processRules();
		// customerDataDistanceLoad();

		// streamingProcess(args);

		System.out.println("Statring the Application ");

		KafkaConfig.topicName = "CUSTOMER_DATA";
		KafkaConfig.senderTopicName = "CUSTOMER_DATA1";
		KafkaConfig.KAFKA_BROKERS = "localhost:9092";

		App appStreaming = new App();
		appStreaming.setPriority(MAX_PRIORITY);
		appStreaming.setName("Start Streaming");
		appStreaming.start();

		App appProducer = new App();
		appProducer.setPriority(MIN_PRIORITY);
		appProducer.setName("Producer Production");
		appProducer.start();

		App appConsumer = new App();
		appConsumer.setPriority(MAX_PRIORITY);
		appConsumer.setName("Consumer Start Consuming");
		appConsumer.start();
		
		App app2ndProducer = new App();
		app2ndProducer.setPriority(MIN_PRIORITY);
		app2ndProducer.setName("Producer 2nd Production");
		app2ndProducer.start();
	}

	private static void customerDataDistanceLoad()
			throws StreamingQueryException, DroolsParserException, IOException, InterruptedException {
		System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
		System.setProperty("hadoop.tmp.dir", "C:\\tmp\\tmp");
		SparkSessionObj.loadSparkSesison();
		LoadCustomerData.loadUDFIntoSparkSession();
		LoadCustomerData.loadRuleEnginee(".\\src\\main\\resources\\Rules.drl");
		LoadCustomerData.loadCusometData(".\\src\\main\\resources\\Mall_Customers.csv");
		// LoadCustomerData.loadCustomerDistance(".\\src\\main\\resources\\CustomerDetailsNearMall.csv");
		LoadCustomerData.processTheRecords();

	}

	public static void streamingProcess(String[] args)
			throws DroolsParserException, IOException, InterruptedException, StreamingQueryException {
		System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
		System.setProperty("hadoop.tmp.dir", "C:\\tmp\\tmp");
		SparkSessionObj.loadSparkSesison();
		LoadCustomerData.loadUDFIntoSparkSession();
		LoadCustomerData.loadRuleEnginee(".\\src\\main\\resources\\Rules.drl");
		LoadCustomerData.loadCusometData(".\\src\\main\\resources\\Mall_Customers.csv");
		// CustomerDataProducer.postMessageToTopic();
		LoadCustomerData.loadTheStream();
		// LoadCustomerData.processTheRecords();

	}

	public static void processRules() throws DroolsParserException, IOException {
		App app = new App();
		app.executeDrools();

		System.setProperty("hadoop.home.dir", "C:\\tmp\\hadoop\\");
		SparkSessionObj.loadSparkSesison();
		LoadCustomerData.loadRuleEnginee(".\\src\\main\\resources\\Rules.drl");
		LoadCustomerData.loadCusometData(".\\src\\main\\resources\\Mall_Customers.csv");
		LoadCustomerData.loadCustomerArroundMall(".\\src\\main\\resources\\DataArroundMall.csv");
		Dataset combinedData = LoadCustomerData.joinData();

		LoadCustomerData.loadUDFIntoSparkSession();
		LoadCustomerData.executeRuleOnDataSet(combinedData);
	}

	public void executeDrools() throws DroolsParserException, IOException {

		PackageBuilder packageBuilder = new PackageBuilder();

		String ruleFile = ".\\src\\main\\resources\\Rules.drl";
		// InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
		// Reader reader = new InputStreamReader(resourceAsStream);
		Reader reader = new InputStreamReader(new FileInputStream(ruleFile));
		packageBuilder.addPackageFromDrl(reader);
		org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
		RuleBase ruleBase = RuleBaseFactory.newRuleBase();
		ruleBase.addPackage(rulesPackage);

		WorkingMemory workingMemory = ruleBase.newStatefulSession();

		OfferRules offerRules = new OfferRules();
		offerRules.setAge(41);
		offerRules.setIncome(6000);
		offerRules.setIsArroundMall("Y");
		offerRules.setGender("F");

		workingMemory.insert(offerRules);
		workingMemory.fireAllRules();

		System.out.println(offerRules.getDiscount());
	}

}
