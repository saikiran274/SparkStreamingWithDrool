package edu.bitsassgn2.pojo;

public class OfferRules {
	public String customerId;
	public String gender;
	public int age;
	public int income;
	public int spendScore;
	public String inMall;
	public String isArroundMall;
	public String discount;
	
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	public int getSpendScore() {
		return spendScore;
	}
	public void setSpendScore(int spendScore) {
		this.spendScore = spendScore;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getInMall() {
		return inMall;
	}
	public void setInMall(String inMall) {
		this.inMall = inMall;
	}
	public String getIsArroundMall() {
		return isArroundMall;
	}
	public void setIsArroundMall(String isArroundMall) {
		this.isArroundMall = isArroundMall;
	}
	
	

}
