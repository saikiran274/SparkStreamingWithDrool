package edu.bitsassgn2.pojo;

public class customerDistanceData {
	public String customerId;
	public int distance;

	public customerDistanceData(String customerId, int distance) {
		super();
		this.customerId = customerId;
		this.distance = distance;
	};

}
