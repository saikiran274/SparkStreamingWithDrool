package edu.bitsassgn2;

public class ConsumeMessages {
	
	public static void main(String[] args) {
		CustomerOfferConsumer.consumeRecords();
	}

}
