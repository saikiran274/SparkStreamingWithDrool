package edu.bitsassgn2;

public class ObjectParsing {

	public static void main(String[] args) {
		String  output = "";
		
	}
}
